window.BlackVinylDiskConfig = {
  "version": 1,
  "settings": {
    "infoScale": 1,
    "playerScale": 1,
    "listScale": 1,
    "playerStyle": "line",
    "volume": 0.65,
    "waveGain": 1,
    "repeat": "all",
    "waveMode": "auto",
    "audioDisplay": "volume"
  },
  "playlists": [],
  "activePlaylistId": null,
  "trackId": null,
  "collapsed": {
    "all": false,
    "current": false,
    "saved": false
  },
  "background": {
    "color": "#000000",
    "image": "",
    "x": 50,
    "y": 50,
    "scale": 1,
    "crop": {
      "x": 0,
      "y": 0,
      "width": 1,
      "height": 1
    }
  }
}
;