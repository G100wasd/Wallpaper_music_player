(function(){'use strict';
const $=id=>document.getElementById(id),C=BlackVinylConfig;
const uid=()=>crypto.randomUUID ? crypto.randomUUID() : Date.now().toString(36)+Math.random().toString(36).slice(2);
const svg=name=>{const e=document.createElement('span');e.textContent='×';return e;};
const emptyRow=text=>{const e=document.createElement('div');e.className='empty-list';e.textContent=text;return e;};
function fillRange(input){input.style.setProperty('--fill',(input.value-input.min)/(input.max-input.min)*100+'%');}
function message(text,error=false){$('config-message').textContent=text;$('config-message').classList.toggle('error',error);}
function applyAppearance(){}
let draft=C.normalize(C.defaults),config=draft,editId=null,draftImported=false;
async function readConfig(){try{draft=C.normalize(await LocalConfig.read());config=draft;editId=draft.activePlaylistId;renderEditor();renderDisplaySettings();message('已连接当前壁纸文件夹。保存后壁纸自动更新。');}catch(e){message('首次使用请运行此壁纸文件夹中的“启用自动启动.cmd”；已启用时可运行 Start-Config.cmd 重试，然后点击“重新读取”。'+e.message,true);}}
async function importAudio(files){$('save-config').disabled=true;try{const list=editedList(true);for(const file of files){message('正在复制：'+file.name);const result=await LocalConfig.call('music','POST',file,{'X-Filename':encodeURIComponent(file.name)});list.tracks.push({id:uid(),title:file.name.replace(/\.[^.]+$/,''),filename:file.name,sourceType:'url',src:result.src,duration:0,artist:''});}renderEditor();message('音乐已复制，点击保存到壁纸后生效。');}catch(e){message(e.message,true);}finally{$('save-config').disabled=false;$('audio-files').value='';}}
async function saveConfig(){try{const next=C.normalize(draft);await LocalConfig.call('config','POST',JSON.stringify(next));draft=next;config=next;message('已写入 config.json，壁纸将在约 2 秒内更新。');}catch(e){message('保存失败：'+e.message,true);}}
  function editedList(create = false) {
    let list = draft.playlists.find(item => item.id === editId);
    if (!list && create) { list = { id: uid(), name: '我的歌单', tracks: [] }; draft.playlists.push(list); editId = list.id; if (!draft.activePlaylistId) draft.activePlaylistId = list.id; }
    return list;
  }
  function renderEditor() {
    const select = $('edit-playlist'); select.replaceChildren();
    if (!draft.playlists.length) { const option = document.createElement('option'); option.textContent = '暂无歌单'; option.value = ''; select.append(option); }
    draft.playlists.forEach(list => { const option = document.createElement('option'); option.value = list.id; option.textContent = list.name; select.append(option); });
    const list = editedList(); select.value = list ? list.id : '';
    $('playlist-name').value = list ? list.name : ''; $('playlist-name').disabled = !list; $('delete-playlist').disabled = !list;
    $('edit-tracks').replaceChildren();
    if (!list || !list.tracks.length) $('edit-tracks').append(emptyRow('导入音乐后，歌曲会出现在这里。'));
    else list.tracks.forEach((track, index) => {
      const row = document.createElement('div'); row.className = 'edit-track';
      const number = document.createElement('span'); number.className = 'track-number'; number.textContent = String(index + 1).padStart(2, '0');
      const title = document.createElement('span'); title.textContent = track.title; title.title = track.filename || track.title;
      const remove = document.createElement('button'); remove.className = 'icon-button remove-track'; remove.setAttribute('aria-label', '移除 ' + track.title); remove.append(svg('close'));
      remove.addEventListener('click', () => { list.tracks.splice(index, 1); renderEditor(); });
      row.append(number, title, remove); $('edit-tracks').append(row);
    });
    $('repeat-mode').value = draft.settings.repeat;
  }
  function renderDisplaySettings() {
    document.querySelectorAll('[data-setting]').forEach(input => { input.value = Math.round(draft.settings[input.dataset.setting] * 100); input.nextElementSibling.textContent = input.value + '%'; fillRange(input); });
  }
  function selectTab(name) {
    document.querySelectorAll('[data-tab]').forEach(tab => { const active = tab.dataset.tab === name; tab.classList.toggle('active', active); tab.setAttribute('aria-selected', String(active)); tab.tabIndex = active ? 0 : -1; });
    document.querySelectorAll('.tab-panel').forEach(panel => panel.hidden = panel.id !== 'panel-' + name);
  }
  function exportJSON() {
    const data = C.normalize(draft || config), blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob), link = document.createElement('a'); link.href = url; link.download = 'black-vinyl.config.json';
    document.body.append(link); link.click(); link.remove(); setTimeout(() => URL.revokeObjectURL(url), 30000); message('已导出配置 JSON。音乐文件单独保存在本机。');
  }
    document.querySelectorAll('[data-tab]').forEach(tab => {
      tab.addEventListener('click', () => selectTab(tab.dataset.tab));
      tab.addEventListener('keydown', event => {
        if (!['ArrowRight', 'ArrowLeft'].includes(event.key)) return;
        event.preventDefault(); const tabs = [...document.querySelectorAll('[data-tab]')];
        const next = tabs[(tabs.indexOf(tab) + (event.key === 'ArrowRight' ? 1 : 2)) % 3]; selectTab(next.dataset.tab); next.focus();
      });
    });
    $('edit-playlist').addEventListener('change', () => { editId = $('edit-playlist').value; renderEditor(); });
    $('new-playlist').addEventListener('click', () => {
      const list = { id: uid(), name: '新歌单', tracks: [] }; draft.playlists.push(list); editId = list.id;
      if (!draft.activePlaylistId) draft.activePlaylistId = list.id; renderEditor(); $('playlist-name').focus(); $('playlist-name').select();
    });
    $('playlist-name').addEventListener('input', () => { const list = editedList(); if (list) { list.name = $('playlist-name').value || '未命名歌单'; const option = [...$('edit-playlist').options].find(item => item.value === list.id); if (option) option.textContent = list.name; } });
    $('delete-playlist').addEventListener('click', () => { draft.playlists = draft.playlists.filter(list => list.id !== editId); if (draft.activePlaylistId === editId) draft.activePlaylistId = (draft.playlists[0] || {}).id || null; editId = (draft.playlists[0] || {}).id || null; renderEditor(); });
    $('audio-files').addEventListener('change', event => importAudio(Array.from(event.target.files)));
    document.querySelectorAll('.file-button').forEach(label => label.addEventListener('keydown', event => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); label.querySelector('input').click(); } }));
    $('add-source').addEventListener('click', () => {
      const src = $('source-url').value.trim();
      try {
        if (!C.safeSource(src)) throw new Error('请填写有效的音频链接或本地文件路径。'); MusicLibrary.safeSource(src);
        const list = editedList(true); let filename = src.split(/[\\/]/).pop().split('?')[0]; try { filename = decodeURIComponent(filename); } catch (_) {}
        list.tracks.push({ id: uid(), title: $('source-title').value.trim() || filename || '未命名音乐', artist: '', filename, duration: 0, sourceType: 'url', src });
        $('source-url').value = ''; $('source-title').value = ''; renderEditor(); message('音频地址已加入，保存后生效。');
      } catch (error) { message(error.message, true); }
    });
    $('repeat-mode').addEventListener('change', () => draft.settings.repeat = $('repeat-mode').value);
    document.querySelectorAll('[data-setting]').forEach(input => input.addEventListener('input', () => { draft.settings[input.dataset.setting] = Number(input.value) / 100; input.nextElementSibling.textContent = input.value + '%'; fillRange(input); applyAppearance(draft.settings); }));
    $('export-json').addEventListener('click', exportJSON);
    $('import-json').addEventListener('change', async event => {
      const file = event.target.files[0]; if (!file) return;
      try {
        if (file.size > 5 * 1024 * 1024) throw new Error('配置文件过大，请选择小于 5 MB 的 JSON。');
        const next = C.normalize(JSON.parse(await file.text())); if (!draft) return;
        draft = next; draftImported = true; editId = next.activePlaylistId || (next.playlists[0] || {}).id || null;
        renderEditor(); renderDisplaySettings(); applyAppearance(draft.settings); message('配置已读取。点击“保存到壁纸”后生效。');
      } catch (error) { message(error instanceof SyntaxError ? 'JSON 格式不正确，请检查配置文件。' : error.message, true); }
      event.target.value = '';
    });

$('save-config').addEventListener('click',saveConfig);$('cancel-config').addEventListener('click',readConfig);renderEditor();renderDisplaySettings();readConfig();})();
